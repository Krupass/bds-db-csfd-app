CREATE ROLE manager
NOSUPERUSER LOGIN
PASSWORD 'Abs0lutely$ecureP4sswordThatNoOneC4nGuess0rBruteForce_123456789_';

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE SCHEMA IF NOT EXISTS csfd_app;

GRANT CONNECT ON DATABASE "bds-db-design3" TO manager;
GRANT ALL PRIVILEGES ON DATABASE "bds-db-design3" TO manager;
GRANT USAGE ON SCHEMA csfd_app TO manager;
GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES, TRIGGER, TRUNCATE ON ALL TABLES IN SCHEMA csfd_app TO manager;
GRANT SELECT, INSERT, UPDATE, DELETE, REFERENCES, TRIGGER, TRUNCATE ON ALL TABLES IN SCHEMA public TO manager;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA csfd_app TO manager;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA csfd_app TO manager;

CREATE TABLE csfd_app.address (
    id_address integer NOT NULL,
    country character varying(45) NOT NULL,
    zip_code character varying(45) NOT NULL,
    city character varying(45) NOT NULL,
    street_name character varying(45) NOT NULL,
    house_number character varying(45) NOT NULL
);


ALTER TABLE csfd_app.address OWNER TO manager;

CREATE SEQUENCE csfd_app.address_id_address_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;

CREATE TABLE csfd_app.country (
    id_country integer NOT NULL,
    country_name character varying(45) NOT NULL,
    language character varying(45) NOT NULL,
    flag character varying(256) NOT  NULL,
    description character varying(256)
);


ALTER TABLE csfd_app.country OWNER TO manager;

CREATE SEQUENCE csfd_app.country_id_country_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.country_id_country_seq OWNER TO manager;

CREATE TABLE csfd_app.favourites (
    id_user integer NOT NULL,
    id_person integer NOT NULL
);


ALTER TABLE csfd_app.favourites OWNER TO manager;

CREATE TABLE csfd_app.genre (
    id_title integer NOT NULL,
    id_genre_name integer NOT NULL
);


ALTER TABLE csfd_app.genre OWNER TO manager;

CREATE TABLE csfd_app.genre_name (
    id_genre_name integer NOT NULL,
    genre_name character varying(45) NOT NULL,
    description character varying(256)
);


ALTER TABLE csfd_app.genre_name OWNER TO manager;

CREATE SEQUENCE csfd_app.genre_name_id_genre_name_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.genre_name_id_genre_name_seq OWNER TO manager;

CREATE TABLE csfd_app.person (
    id_person integer NOT NULL,
    id_address integer NOT NULL,
    first_name character varying(45) NOT NULL,
    surname character varying(45) NOT NULL,
    date_of_birth date NOT NULL
);


ALTER TABLE csfd_app.person OWNER TO manager;

CREATE SEQUENCE csfd_app.person_id_person_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.person_id_person_seq OWNER TO manager;

CREATE TABLE csfd_app.rating (
    id_user integer NOT NULL,
    id_title integer NOT NULL,
    rating integer NOT NULL,
    reason character varying(256)
);


ALTER TABLE csfd_app.rating OWNER TO manager;

CREATE TABLE csfd_app.role (
    id_title integer NOT NULL,
    id_person integer NOT NULL,
    id_role integer NOT NULL
);


ALTER TABLE csfd_app.role OWNER TO manager;

CREATE TABLE csfd_app.role_name (
    id_role integer NOT NULL,
    role_name character varying(45) NOT NULL,
    description character varying(256)
);


ALTER TABLE csfd_app.role_name OWNER TO manager;

CREATE SEQUENCE csfd_app.role_name_id_role_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.role_name_id_role_seq OWNER TO manager;

CREATE TABLE csfd_app.titles (
    id_title integer NOT NULL,
    id_type integer NOT NULL,
    id_country integer NOT NULL,
    name character varying(45) NOT NULL,
    year date NOT NULL,
    lenght integer NOT NULL,
    description character varying(256) NOT NULL
);


ALTER TABLE csfd_app.titles OWNER TO manager;

CREATE SEQUENCE csfd_app.titles_id_title_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.titles_id_title_seq OWNER TO manager;

CREATE TABLE csfd_app.type (
    id_type integer NOT NULL,
    type_name character varying(45) NOT NULL,
    description character varying(256)
);


ALTER TABLE csfd_app.type OWNER TO manager;

CREATE SEQUENCE csfd_app.type_id_type_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.type_id_type_seq OWNER TO manager;

CREATE TABLE csfd_app."user" (
    id_user integer NOT NULL,
    first_name bytea NOT NULL,
    surname bytea NOT NULL,
    nick character varying(45) NOT NULL,
    email bytea NOT NULL,
    password character varying(70) NOT NULL,
    user_created TIMESTAMP(6) NOT NULL,
    id_address integer
);


ALTER TABLE csfd_app."user" OWNER TO manager;

CREATE TABLE public.dummy_table (
    string VARCHAR(200)
);


ALTER TABLE public.dummy_table OWNER TO manager;

CREATE SEQUENCE csfd_app.user_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE csfd_app.user_id_user_seq OWNER TO manager;

ALTER TABLE ONLY csfd_app.address ALTER COLUMN id_address SET DEFAULT nextval('csfd_app.address_id_address_seq'::regclass);

ALTER TABLE ONLY csfd_app.country ALTER COLUMN id_country SET DEFAULT nextval('csfd_app.country_id_country_seq'::regclass);

ALTER TABLE ONLY csfd_app.genre_name ALTER COLUMN id_genre_name SET DEFAULT nextval('csfd_app.genre_name_id_genre_name_seq'::regclass);

ALTER TABLE ONLY csfd_app.person ALTER COLUMN id_person SET DEFAULT nextval('csfd_app.person_id_person_seq'::regclass);

ALTER TABLE ONLY csfd_app.role_name ALTER COLUMN id_role SET DEFAULT nextval('csfd_app.role_name_id_role_seq'::regclass);

ALTER TABLE ONLY csfd_app.titles ALTER COLUMN id_title SET DEFAULT nextval('csfd_app.titles_id_title_seq'::regclass);

ALTER TABLE ONLY csfd_app.type ALTER COLUMN id_type SET DEFAULT nextval('csfd_app.type_id_type_seq'::regclass);

ALTER TABLE ONLY csfd_app."user" ALTER COLUMN id_user SET DEFAULT nextval('csfd_app.user_id_user_seq'::regclass);

ALTER TABLE ONLY csfd_app.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (id_address);

ALTER TABLE ONLY csfd_app.country
    ADD CONSTRAINT country_pkey PRIMARY KEY (id_country);

ALTER TABLE ONLY csfd_app.favourites
    ADD CONSTRAINT favourites_pkey PRIMARY KEY (id_user, id_person);

ALTER TABLE ONLY csfd_app.genre_name
    ADD CONSTRAINT genre_name_genre_name_key UNIQUE (genre_name);

ALTER TABLE ONLY csfd_app.genre_name
    ADD CONSTRAINT genre_name_pkey PRIMARY KEY (id_genre_name);

ALTER TABLE ONLY csfd_app.genre
    ADD CONSTRAINT genre_pkey PRIMARY KEY (id_title, id_genre_name);

ALTER TABLE ONLY csfd_app.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id_person);

ALTER TABLE ONLY csfd_app.rating
    ADD CONSTRAINT rating_pkey PRIMARY KEY (id_user, id_title);

ALTER TABLE ONLY csfd_app.role_name
    ADD CONSTRAINT role_name_pkey PRIMARY KEY (id_role);

ALTER TABLE ONLY csfd_app.role_name
    ADD CONSTRAINT role_name_role_name_key UNIQUE (role_name);

ALTER TABLE ONLY csfd_app.role
    ADD CONSTRAINT role_pkey PRIMARY KEY (id_title, id_person, id_role);

ALTER TABLE ONLY csfd_app.titles
    ADD CONSTRAINT titles_id_title_key UNIQUE (id_title);

ALTER TABLE ONLY csfd_app.titles
    ADD CONSTRAINT titles_pkey PRIMARY KEY (id_title, id_type);

ALTER TABLE ONLY csfd_app.type
    ADD CONSTRAINT type_pkey PRIMARY KEY (id_type);

ALTER TABLE ONLY csfd_app.type
    ADD CONSTRAINT type_type_name_key UNIQUE (type_name);

ALTER TABLE ONLY csfd_app."user"
    ADD CONSTRAINT user_nick_key UNIQUE (nick);

ALTER TABLE ONLY csfd_app."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id_user);

ALTER TABLE ONLY csfd_app.favourites
    ADD CONSTRAINT fk_favourites_person1 FOREIGN KEY (id_person) REFERENCES csfd_app.person(id_person);

ALTER TABLE ONLY csfd_app.favourites
    ADD CONSTRAINT fk_favourites_user FOREIGN KEY (id_user) REFERENCES csfd_app."user"(id_user);

ALTER TABLE ONLY csfd_app.genre
    ADD CONSTRAINT fk_genre_genre_name1 FOREIGN KEY (id_genre_name) REFERENCES csfd_app.genre_name(id_genre_name);

ALTER TABLE ONLY csfd_app.genre
    ADD CONSTRAINT fk_genre_titles1 FOREIGN KEY (id_title) REFERENCES csfd_app.titles(id_title);

ALTER TABLE ONLY csfd_app.person
    ADD CONSTRAINT fk_person_address1 FOREIGN KEY (id_address) REFERENCES csfd_app.address(id_address);

ALTER TABLE ONLY csfd_app.rating
    ADD CONSTRAINT fk_rating_titles1 FOREIGN KEY (id_title) REFERENCES csfd_app.titles(id_title);

ALTER TABLE ONLY csfd_app.rating
    ADD CONSTRAINT fk_rating_user1 FOREIGN KEY (id_user) REFERENCES csfd_app."user"(id_user);

ALTER TABLE ONLY csfd_app.role
    ADD CONSTRAINT fk_role_person1 FOREIGN KEY (id_person) REFERENCES csfd_app.person(id_person);

ALTER TABLE ONLY csfd_app.role
    ADD CONSTRAINT fk_role_role_name1 FOREIGN KEY (id_role) REFERENCES csfd_app.role_name(id_role);


ALTER TABLE ONLY csfd_app.role
    ADD CONSTRAINT fk_role_titles1 FOREIGN KEY (id_title) REFERENCES csfd_app.titles(id_title);

ALTER TABLE ONLY csfd_app.titles
    ADD CONSTRAINT fk_titles_country1 FOREIGN KEY (id_country) REFERENCES csfd_app.country(id_country);

ALTER TABLE ONLY csfd_app.titles
    ADD CONSTRAINT fk_titles_type1 FOREIGN KEY (id_type) REFERENCES csfd_app.type(id_type);

ALTER TABLE ONLY csfd_app."user"
    ADD CONSTRAINT fk_user_address1 FOREIGN KEY (id_address) REFERENCES csfd_app.address(id_address);