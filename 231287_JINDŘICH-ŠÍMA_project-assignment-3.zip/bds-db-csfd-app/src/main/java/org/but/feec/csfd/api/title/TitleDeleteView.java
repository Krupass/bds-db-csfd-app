package org.but.feec.csfd.api.title;

public class TitleDeleteView {
    private Long id;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
