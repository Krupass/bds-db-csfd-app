package org.but.feec.csfd.api.user;

public class UserDeleteView {
    private Long id;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
