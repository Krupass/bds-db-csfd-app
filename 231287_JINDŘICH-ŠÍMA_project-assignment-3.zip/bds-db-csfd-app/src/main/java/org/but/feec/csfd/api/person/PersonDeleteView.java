package org.but.feec.csfd.api.person;

public class PersonDeleteView {
    private Long id;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
