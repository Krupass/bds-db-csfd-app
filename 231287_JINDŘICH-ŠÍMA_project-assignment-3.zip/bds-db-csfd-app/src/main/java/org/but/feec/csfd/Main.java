package org.but.feec.csfd;

public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}
